package wolfPub;

public class Trial {
	public static void main(String[] args) {
		Position javaPos = new Position("pos102", -1);
		
//		Position returnedObj = Position.getPositionById(2);
//		System.out.println(returnedObj.getPositionId());
//		System.out.println(returnedObj.getPositionName());
//		
//		Position returnedObj2 = Position.getPositionByName("JavaPos");
//		System.out.println(returnedObj2.getPositionId());
//		System.out.println(returnedObj2.getPositionName());
//		
//		returnedObj.removePosition(-1);
		
//		System.out.println("adding invited employee");
//		InvitedEmployee ie = new InvitedEmployee("JavaIE2", returnedObj, 300, -1);
//		System.out.println(ie.getEmployeeId());
//		System.out.println(ie.getEmployeeName());
//		System.out.println(ie.getWage());
//		System.out.println(ie.getEmpPosition().getPositionName());
//		
//		System.out.println("adding staff employee");
//		StaffEmployee staff = new StaffEmployee("JavaStaff", returnedObj, 300, -1);
//		System.out.println(staff.getEmployeeId());
//		System.out.println(staff.getEmployeeName());
//		System.out.println(staff.getSalary());
//		System.out.println(staff.getEmpPosition().getPositionName());
//		
//		Employee empToGet = ie;
//		System.out.println("getting invited employee");
//		String empType = Employee.getEmployeeTypeById(empToGet.getEmployeeId());
//		if(empType.equals("invited")) {
//			InvitedEmployee eReturned = (InvitedEmployee)Employee.getEmployee(empToGet.getEmployeeId());
//			System.out.println(eReturned.getEmployeeId());
//			System.out.println(eReturned.getEmployeeName());
//			System.out.println(eReturned.getEmpPosition().getPositionName());
//			System.out.println(eReturned.getWage());
//		}
//		else if(empType.equals("staff")) {
//			StaffEmployee eReturned = (StaffEmployee)Employee.getEmployee(empToGet.getEmployeeId());
//			System.out.println(eReturned.getEmployeeId());
//			System.out.println(eReturned.getEmployeeName());
//			System.out.println(eReturned.getEmpPosition().getPositionName());
//			System.out.println(eReturned.getSalary());
//		}
//		
//		Employee staffReturned = Employee.getEmployee(staff.getEmployeeId());
//		System.out.println("updating employee");
//		staffReturned.updateEmployee("updatedStaffEmp", "javaPos", -1);
//		Employee updatedStaff = Employee.getEmployee(staff.getEmployeeId());
//		System.out.println(updatedStaff.getEmployeeId());
//		System.out.println(updatedStaff.getEmployeeName());
//		System.out.println(updatedStaff.getEmpPosition().getPositionName());
//		
//		System.out.println("updating employee")
//		staffReturned.updateEmployee("updatedStaffEmp", "author", -1);
//		updatedStaff = Employee.getEmployee(staff.getEmployeeId());
//		System.out.println(updatedStaff.getEmployeeId());
//		System.out.println(updatedStaff.getEmployeeName());
//		System.out.println(updatedStaff.getEmpPosition().getPositionName());
		
//		ie.removeEmployee(-1);
		
		
//		System.out.println(Employee.getEmployeeTypeById(35));
	}
}
